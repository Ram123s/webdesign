import React from 'react'
import './Blog.css'

import Clap_icon from '../Assets/applaud-checked.png'
import { TiSocialTwitterCircular } from "react-icons/ti";
import { PiFacebookLogoBold } from "react-icons/pi";
import { TiSocialLinkedinCircular } from "react-icons/ti";
import { FaRegComment } from "react-icons/fa6";

import profile_icon from "../Assets/profile.jpg"

const Blog = () => {
    return (
        <>
            <div>
                <div className="container">
                    {/* side Bar Start*/}
                    <div className="row ">
                        <div className='col-lg-2 '  >

                            <div className='claps_img'>

                                <img src={Clap_icon} alt="" />
                            </div>
                            <p className='share_color'>Share</p>

                            <div className='social_icons'>
                                <div className="twitter_icon">
                                    <a href="#"><TiSocialTwitterCircular /> </a>
                                </div>
                                <div className="facebook_icon">
                                    <a href="#"><PiFacebookLogoBold /> </a>
                                </div>
                                <div className="linkedin_icon">
                                    <a href="#"><TiSocialLinkedinCircular /></a>
                                </div>
                            </div>
                            <div>___ </div>

                            <div className="comments">

                                <p> Reply</p>

                                <a href=""><FaRegComment /></a>
                            </div>
                        </div>
                        {/* side Bar end*/}


                        <div className='col-lg-8'  >
                            {/* content start */}
                            <div className='header'>

                                <div>
                                    <img src={profile_icon} alt="" />
                                </div>
                                <div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet, officiis.</div>


                            </div>


                        </div>
                        {/* content end */}
                    </div>
                </div>






            </div>
        </>
    )
}

export default Blog