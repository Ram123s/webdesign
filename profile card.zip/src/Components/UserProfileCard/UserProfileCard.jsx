import React from 'react'
import './UserProfileCard.css'

import profile_icon from '../Assets/elon_musk.jpg'
const UserProfileCard = () => {
  return (
    <div className='upc'>
<div className="gradiant"></div>
<div className="profile-down">
    <img src={profile_icon} alt="" />
    <div className="profile-title">
ELON MUSK
    </div>
    <div className="profile-description">
I am a founder,chairman & executive officer of SpaceX,CEO and product architect of Tesla inc. owner and CTO of twitter
    </div>
    <div className="profile-bottom"><a href="mailto:elon@musk.com">Contact Me</a></div>
</div>
    </div>
  )
}

export default UserProfileCard