import logo from './logo.svg';
import './App.css';
import UserProfileCard from './Components/UserProfileCard/UserProfileCard';

function App() {
  return (
    <div >
      <UserProfileCard/>
      
    </div>
  );
}

export default App;
