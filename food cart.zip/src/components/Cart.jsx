import React from 'react'

export const Cart = () => {
  return (
    <div>this is cart page</div>
  )
}
