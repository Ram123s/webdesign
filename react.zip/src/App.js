import logo from './logo.svg';
import './App.css';

function App() {
  return (
  <h2>
    Hello coders
  </h2>
  );
}

export default App;
