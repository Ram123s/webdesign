function Car(props){

const {carInfo} = props
const{ brand,color} =carInfo
const  text =`hi,i am ${color} ${brand} car` ;
//  if you include the in between the words  use bactick symbol ` `
    return(
      <h2> {text}</h2>
    );
  }

  export default  Car;