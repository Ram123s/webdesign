import './Header.css'
import styles from './header.module.css'

function Header() {

    const myStyle ={
        color: 'red',
        backgroundColor: 'DodgerBlue',
   padding:"22px",
   fontFamily: "sans-serif"
    }



  return (
    <div>
        <h1 style={myStyle}>Hello styling</h1>

        <h3 className={styles.bigBlue}>lh9ij diurtg bhfbis</h3>
        <p>Add a little style</p>
    </div>
  )
}

export default Header;