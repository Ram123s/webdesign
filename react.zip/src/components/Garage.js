import Car from './car'
import Apple from './Apple';


function Garage(){
  const isDoorOpened= false ;
//   const brand = 'ferrai';
// const color = 'black';

const carInfo = { brand:"ferrai",color:"black" } // funcompound
// while create Object is many componts through easlily

const appleInfo ={ type:"fuji",color:"red"};
 // classcompound


 //List
 const carList =[
  {brand:"BMW",color:"RED"},
  {brand:"FORD",color:"GREEN"},
  {brand:"TESLA",color:"BLUE"},
 ]


 //keys
 const numberList = [
  1,2,3,4,3,,5
 ];

 //conditional rendering
 // const carInfo = {}
 const showCarInfo = carInfo.brand !==undefined && carInfo.color !==undefined;
    return(
    <div>
      <h1>
        Who lives in my Garage?
      </h1>

      {/* -->coditional statement */}
      {showCarInfo? 
        <Car carInfo={carInfo}/> :null
                         // true:false
    }
    
      <Apple appleInfo={appleInfo} />

      {isDoorOpened? <h2>Garage is open</h2>:<h2>Garege is closed</h2> }

      {/* // list */}
      <ul>
      { carList.map((carInfo) => <li key={carInfo.brand}> <Car carInfo={carInfo} /></li>)}
      </ul>
{/* keys */}
<ul> 
  {/* {numberList.map((number) => <li key={number}>{number}</li>)} */}
  {numberList.map((e,index) => <p key={index}>{e}</p>)}
</ul>

    </div>
   
    )
  }
  export default Garage;