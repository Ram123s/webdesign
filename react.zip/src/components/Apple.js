import React, { Component } from 'react'

export default class Apple extends Component {
  render() {
     const  { appleInfo} = this.props
     const { type,color} = appleInfo
    return (
     <> I am {type} {color} Apple</>
    )
  }
}
