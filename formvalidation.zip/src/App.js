import Form from './components/Form'
import File from './components/File'


function App() {
  return (
   <div>
<Form/>
<File/>

   </div>
  );
}

export default App;
