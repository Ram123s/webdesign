import React, { useState } from 'react';
import './File.css';
import '@fortawesome/fontawesome-free/css/all.min.css'; // Import FontAwesome CSS

const File = () => {
  const [file, setFile] = useState({
    name: '',
    email: '@gmail.com',
    password: '',
    phone: '+91',
  });

  const [errors, setErrors] = useState({});
  const [showToast, setShowToast] = useState(false); // State to manage the visibility of the toast message

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFile({
      ...file,
      [name]: value,
    });
  };

  const validate = () => {
    const newErrors = {};
    if (!file.name) {
      newErrors.name = 'Name is required';
    }
    if (!file.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(file.email)) {
      newErrors.email = 'Email is not valid';
    }
    if (!file.phone) {
      newErrors.phone = 'Mobile number is required';
    } else if (!/[6-9][0-9]{9}/.test(file.phone)) {
      newErrors.phone = 'Mobile number is invalid';
    }
    if (!file.password) {
      newErrors.password = 'Password is required';
    } else if (file.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      console.log('Form submitted', file);
      setShowToast(true); // Show the toast message
      setTimeout(() => setShowToast(false), 3500); // Hide the toast message after 3.5 seconds
      // You can now send the data to an API, e.g., using fetch or axios
    }
  };

  // Password visibility
  const [passwordVisible, setPasswordVisible] = useState(false);
  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  return (
    <div>
      <div className="toast-container">
        {showToast && (
          <div className="toast">
            <span>Form submitted successfully!</span>
            <button onClick={() => setShowToast(false)}>&times;</button>
          </div>
        )}
      </div>
      <form className="container mt-5" onSubmit={handleSubmit}>
        <div className="row mb-3 mt-5">
          <div className="col-2"></div>
          <label htmlFor="inputName" className="col-sm-2 col-form-label text-end">Name</label>
          <div className="col-sm-6">
            <input
              type="text"
              name="name"
              value={file.name}
              onChange={handleChange}
              className="form-control"
              id="inputName"
              placeholder="Enter your name"
              required
            />
            {errors.name && <div className="text-danger">{errors.name}</div>}
          </div>
          <div className="col-2"></div>
        </div>
        <div className="row mb-3">
          <div className="col-2"></div>
          <label htmlFor="inputEmail" className="col-sm-2 col-form-label text-end">Email</label>
          <div className="col-sm-6">
            <input
              type="email"
              name="email"
              value={file.email}
              onChange={handleChange}
              className="form-control"
              id="inputEmail"
              placeholder="Enter your email"
              required
            />
            {errors.email && <div className="text-danger">{errors.email}</div>}
          </div>
        </div>
        <div className="row mb-3">
          <div className="col-2"></div>
          <label htmlFor="inputMobile" className="col-sm-2 col-form-label text-end">Mobile No</label>
          <div className="col-sm-6">
            <input
              type="tel"
              className="form-control"
              name="phone"
              value={file.phone}
              onChange={handleChange}
              id="inputMobile"
              pattern="[6-9][0-9]{9}"
              placeholder="Enter your mobile number"
              required
            />
            {errors.phone && <div className="text-danger">{errors.phone}</div>}
          </div>
        </div>
        <div className="row mb-3">
          <div className="col-2"></div> {/* Empty column for spacing */}
          <label htmlFor="inputPassword" className="col-sm-2 col-form-label text-end">Password</label>
          <div className="col-sm-6 position-relative">
            <input
              type={passwordVisible ? 'text' : 'password'}
              className="form-control"
              name="password"
              value={file.password}
              onChange={handleChange}
              id="inputPassword"
              placeholder="Enter your password"
              required
            />
            {errors.password && <div className="text-danger">{errors.password}</div>}
            <button
              type="button"
              className="btn btn-link position-absolute end-0 top-0 mt-2 me-2 p-0"
              onClick={togglePasswordVisibility}
              style={{ textDecoration: 'none', border: 'none', background: 'transparent' }}
            >
              <i className={`fas ${passwordVisible ? 'fa-eye' : 'fa-eye-slash'}`}></i>
            </button>
          </div>
        </div>
        <div className="row mb-3">
          <div className="col-12 d-flex justify-content-center">
            <button type="submit" className="btn btn-primary">Sign in</button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default File;
