import React from "react";
import "./Form.css";
const form = () => {
  return (
    <div className="container">
      <form className="fornm">
        <h1 className="text-center">Form</h1>
        <div className="form-group">
          <div className="input text-center">
            <label >Name :</label>
            <input
              type="text"
              name="username"
              placeholder="Username"
              required
            />
          </div>

          <div className="input">
            <label className="al">Education :</label>
            <input type="text" name="Education" placeholder="Qualification" />
          </div>
          <div className="input">
            <label>Mobile No :</label>
            <input type="tel" name="phone" placeholder="Enter your mobile number" required />
          </div>
          <div className="input">
            <label>Email :</label>
            <input
              type="email"
              name="email"
              placeholder="enter your email"
              required
            />
          </div>
          <div className="input">
            <label>Roll no : </label>
            <input
              type="number"
              name="number"
              placeholder="enter your roll no"
            />
          </div>

        
            <button className="btn">Submit</button>
          
        </div>
      </form>
    </div>
  );
};

export default form;
