import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import AppHeader from './Components/header';
import AppHero from './Components/hero';
import AppAbout from './Components/about';
import AppServices from './Components/services';
import AppWorks from './Components/work';
import AppTeams from './Components/teams';
import AppTestimonials from './Components/testimonials';
import AppPricing from './Components/pricing';
import AppBlog from './Components/blog';
import AppContact from './Components/contact';
import AppFooter from './Components/footer';
function App() {
  return (
    <div className="App">
<header id='header'>
  <AppHeader/>
</header>

<main>
<AppHero/> 
<AppAbout/>
<AppServices/>
<AppWorks/>
<AppTeams/>
<AppTestimonials/>
<AppPricing/>
<AppBlog/>
<AppContact/>
</main>

<footer id='footer'>
  <AppFooter/>
</footer>

        
    </div>
  );
}

export default App;
