import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Header from "./Pages/Header";
import Home from "./Pages/Home";
import About from "./Pages/About";
import Contact from "./Pages/Contact";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Header />} />
          <Route path="/homePage" element={<Home />} />
          <Route path="/aboutPage" element={<About />} />
          <Route path="/contactPage" element={<Contact />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
