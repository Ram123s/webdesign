import React from "react";

const About = () => {
  return (
    <div>
      <div className="">
        <h1>This is About Page</h1>
      </div>
    </div>
  );
};

export default About;
