import React from "react";

const Home = () => {
  return (
    <div>
      <div className="">this is the home page</div>
    </div>
  );
};

export default Home;
