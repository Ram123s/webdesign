import React from "react";

const Contact = () => {
  return (
    <div>
      <div className="">
        <h1>This is Contact Page</h1>
      </div>
    </div>
  );
};

export default Contact;
