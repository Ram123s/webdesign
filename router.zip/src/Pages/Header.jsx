import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <div>
      <div className="container">
        <a href="/homePage">
          <li>Home</li>
        </a>

        <Link to="/aboutPage">
          <li>About</li>
        </Link>

        <a href="contactPage">
          <li>Contact</li>
        </a>


      <a href="summapage">
        <li>Summa</li>
      </a>
      </div>
    </div>
  );
};

export default Header;
