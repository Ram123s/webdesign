import React, { useState ,useMemo} from 'react'

const App1 = () => {
    const[number,setNumber] =useState(0)
    const[counter,setCounter]=useState(0)
    function CubeNum(num){
        console.log("calc done!")
        return Math.pow(num,3)
    }

const result = useMemo(()=> CubeNum(number),[number])
// const result = cubeNum(number)
  return (
    <div>
<input type="number" value={number} onChange={(e)=>{setNumber(e.target.value)}} />
<h1>cube of number:{ result}</h1>
//------------------------------
<button onClick={()=>{setCounter(counter+1)}}>Counter++</button>
<h1> count:{counter}</h1>
    </div>
  )
}

export default App1