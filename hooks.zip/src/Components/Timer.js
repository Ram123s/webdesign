import React,{useState,useEffect} from 'react'

const Timer = () => {
const [count,setCount] = useState(0);
const[calculation,setCalculation]= useState(0);


useEffect(()=>{
    setCalculation(()=>
        (count*9)
    ,[count])
})

  return (
    <div>
<h1> i have {count} times!</h1>
<button onClick={()=>setCount(count+1)}>Click me</button>
<h1> i have {calculation} times!</h1>
    </div>
  )
}

export default Timer