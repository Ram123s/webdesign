import React, { useState } from 'react';

const Contact = () => {
    const [fullname, setName] = useState({ fname: "", lname: "" });
    const { fname, lname } = fullname; // Destructuring fullname object

    const handleChange = (e) => {
        const { name, value } = e.target;
        setName(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    return (
        <div>
            <div>
                <span>FirstName</span>
                <input type='text' name='fname' onChange={handleChange} />
            </div>
            <div>
                <span>Lastname</span>
                <input type='text' name='lname' onChange={handleChange} />
            </div>
            <div>{`${fname} - ${lname}`}</div>
        </div>
    );
};

export default Contact;
