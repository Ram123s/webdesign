import { useState } from "react";

export default function Code() {
  const [count, setCount] = useState(0);
  const [value, setValue] = useState(0);
  const [color, setColor] = useState("red");
  // ---------------
  const [brand, setBrand] = useState("Ford");
  const [model, setModel] = useState("Mustang");
  const [year, setYear] = useState("1964");
  const [colors, setColors] = useState("red");
  //------------------------------------
  const [car, setCar] = useState({
    brand: "Ford",
    model: "Mustang",
    year: "1964",
    color: "red",
    //-------------------------
  });

  return (
    <div>
      <p>You click {count} times</p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
      <div>
        //------------------------------
        <p>decrease cpount {value}</p>
        <button onClick={() => setValue(value - 1)}>clickme</button>
      </div>
      <span>
        <p> My favorite color is {color}</p>
        <button onClick={() => setColor("blue")}>Blue me</button>
        <button onClick={() => setColor("red")}>red me</button>
        <button onClick={() => setColor("green")}>green me</button>
        <button onClick={() => setColor("yellow")}>yellow me</button>
      </span>
      //--------------------------------------
      <span>
        <h1>My {brand}</h1>
        <p>
          It is a {colors} {model} from {year}.
        </p>
      </span>
      //-------------------------------
      <>
        <h1>My {car.brand}</h1>
        <p>
          It is a {car.color} {car.model} from {car.year}.
        </p>
      </>
    </div>
  );
}
