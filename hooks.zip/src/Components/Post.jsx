import React,{useState } from 'react'

const Post = () => {
    const[resourceType,SetResourceType] = useState('posts')
  return (
    <div> <button onClick={() => SetResourceType('posts')}>Posts</button>
    <button onClick={() => SetResourceType('users')}>Users</button>
    <button onClick={() => SetResourceType('comments')}>Comments</button>
<h1>{resourceType}</h1></div>
  )
}

export default Post