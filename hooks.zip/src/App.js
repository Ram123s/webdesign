import logo from './logo.svg';
import './App.css';
import { useEffect, useRef, useState } from 'react';

function App() {
 const inputEle =useRef();
const btnClicked = () =>{
  console.log(inputEle.current)
  inputEle.current.style.background= 'blue'
}

  return (
    <div >
   <input type='text' ref={inputEle}/>
   <button onClick={btnClicked}> click me</button>
    </div>
  );
}

export default App;
