import React from 'react'

const Broweser = () => {
  return (
    <div>Broweser</div>
  )
}

export default Broweser