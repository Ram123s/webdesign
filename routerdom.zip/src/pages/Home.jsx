import React from 'react'

const Home = () => {
  return (
    <div>
      <div>
        werdgy
      </div>
    </div>
  )
}

export default Home