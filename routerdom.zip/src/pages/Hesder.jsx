import React from 'react'
import { Link } from "react-router-dom";
const Hesder = () => {
  return (
    <div>
        <div className='container '>
<a href='/home'>
<li>home</li>
</a>
<a href='/about'>
<li>about</li>
</a>
<a href='/broweser'>
<li>broweser</li>
</a>

        </div>
        </div>
  )
}

export default Hesder