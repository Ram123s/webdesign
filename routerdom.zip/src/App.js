import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Header from './pages/Hesder'
import Home from './pages/Home'
import About from './pages/About';
import Broweser from './pages/Broweser';




function App() {
  return (
    <div className="App">
     <BrowserRouter>
       <Routes>
         <Route path='/' element={<Header/>}/>
         <Route path='/home' element={<Home/>}/>
         <Route path='/about' element={<About/>}/>
         <Route path='/broweser' element={<Broweser/>}/>
       </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
