import React from 'react';
import './Form.css'; // Import the CSS file

const Form = () => {
  return (
    <>
      <form className="form-container">
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" placeholder="name" /> <br />

        <label htmlFor="email">Email:</label>
        <input type="text" id="email" placeholder="email" /><br />

        <label htmlFor="password">Password:</label>
        <input type="text" id="password" placeholder="password" /><br />

        <button type="submit">Submit</button>
      </form>
    </>
  );
}

export default Form;
