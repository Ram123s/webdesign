import API from './api';
import { postUser } from './endpoint';

export const savingUser = (data) => {

    return API.post(`${postUser}/saveUser`, data);

}