import React from 'react'

function About() {
  return (
    <div>About
        <p>This is the about page.</p>
    </div>
  )
}

export default About