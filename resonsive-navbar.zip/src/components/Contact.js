import React from 'react'

function Contact() {
  return (
    <div>Contact
        <p>This is the contact page.</p>
    </div>
  )
}

export default Contact