import React from 'react'

function Home() {
  return (
    <div>Home
        <p>This is the home page.</p>
    </div>
  )
}

export default Home