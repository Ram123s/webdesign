import React from 'react';

// Child Component
const Counter = ({ count, onIncrement }) => {
  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={onIncrement}>Increment</button>
    </div>
  );
};

// Parent Component
class App extends React.Component {
  state = {
    count: 0
  };

  handleIncrement = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <div>
        <Counter count={this.state.count} onIncrement={this.handleIncrement} />
      </div>
    );
  }
}

export default App;
