
import './App.css';
import Project from './Pages/Project';




function App() {
  return (
    <div className="App">
  <Project />
  <card/>

    </div>
  );
}

export default App;
